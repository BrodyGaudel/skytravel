#include <gtk/gtk.h>


void
on_modifierbrody_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimerbrody_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);	

void
on_afficherbrody_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


